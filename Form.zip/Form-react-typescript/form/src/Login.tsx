import './Login.css';
import type { FormEvent } from 'react';

const sendForm = async (event : FormEvent<HTMLFormElement>) => {
  event.preventDefault()

  const { name,password } = event.target as typeof event.target & {
    name : {value:String}
    password : {value:string}
   }
   console.log(name.value,password.value);

}

function App() {
  return (
    <form className='form' onSubmit={evt =>sendForm(evt)}>
        <fieldset className='field'>
          <label htmlFor='name'>Name: </label>
          <input type='text' id='name'/>
        </fieldset>
        <fieldset className='field'>
          <label htmlFor='password'>password: </label>
          <input type='password' id='password' />
        </fieldset>
        <button type='submit'>Login</button>
    </form>
  );
}

export default App;

